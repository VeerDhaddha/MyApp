import React, { useState, useEffect } from 'react';
import { Heart, AlertTriangle, Phone, Clock, ChevronLeft, Timer, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

interface EmergencyScenario {
  id: string;
  title: string;
  icon: React.ReactNode;
  description: string;
  steps: string[];
  emergencyNumber: string;
  timerDuration?: number;
}

const emergencyScenarios: EmergencyScenario[] = [
  {
    id: 'cardiac',
    title: 'Cardiac Arrest',
    icon: <Heart className="w-8 h-8" />,
    description: 'Person unconscious, not breathing',
    steps: [
      'Call 108 immediately',
      'Check for breathing (look, listen, feel for 10 seconds)',
      'Start chest compressions: 30 compressions at 100-120/min',
      'Give 2 rescue breaths if trained',
      'Continue CPR until help arrives or person recovers',
      'Use AED if available - follow voice prompts',
    ],
    emergencyNumber: '108',
    timerDuration: 120,
  },
  {
    id: 'choking',
    title: 'Severe Choking',
    icon: <AlertTriangle className="w-8 h-8" />,
    description: 'Cannot speak, breathe, or cough',
    steps: [
      'Call 108 if person cannot speak or breathe',
      'Stand behind person and wrap arms around waist',
      'Make a fist with one hand, place above navel',
      'Grasp fist with other hand, thrust inward and upward',
      'Perform 5 abdominal thrusts (Heimlich maneuver)',
      'Continue until object is expelled or help arrives',
    ],
    emergencyNumber: '108',
  },
  {
    id: 'bleeding',
    title: 'Severe Bleeding',
    icon: <AlertTriangle className="w-8 h-8" />,
    description: 'Heavy blood loss that won\'t stop',
    steps: [
      'Call 108 immediately',
      'Apply direct pressure with clean cloth or bandage',
      'Elevate the injured area above heart level if possible',
      'Maintain pressure continuously',
      'If blood soaks through, add more cloth - don\'t remove first',
      'Apply tourniquet only if trained and bleeding is life-threatening',
    ],
    emergencyNumber: '108',
    timerDuration: 180,
  },
  {
    id: 'stroke',
    title: 'Stroke',
    icon: <AlertTriangle className="w-8 h-8" />,
    description: 'F.A.S.T: Face drooping, Arm weakness, Speech difficulty',
    steps: [
      'Call 108 immediately - time is brain',
      'Note the time symptoms started',
      'Keep person comfortable and lying on their side',
      'Don\'t give food or drink',
      'Loosen tight clothing',
      'Monitor breathing and consciousness',
    ],
    emergencyNumber: '108',
  },
  {
    id: 'seizure',
    title: 'Seizure',
    icon: <AlertTriangle className="w-8 h-8" />,
    description: 'Convulsions or loss of consciousness',
    steps: [
      'Call 108 if seizure lasts >5 minutes or person is injured',
      'Protect from injury - move objects away',
      'Cushion head with something soft',
      'Turn person on their side if possible',
      'Don\'t restrain or put anything in mouth',
      'Time the seizure - note duration',
    ],
    emergencyNumber: '108',
  },
];

export default function EmergencyGuide({ darkMode }: { darkMode: boolean }) {
  const [selectedScenario, setSelectedScenario] = useState<EmergencyScenario | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [timerActive, setTimerActive] = useState(false);
  const [timerSeconds, setTimerSeconds] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (timerActive && timerSeconds > 0) {
      interval = setInterval(() => {
        setTimerSeconds((prev) => prev - 1);
      }, 1000);
    } else if (timerSeconds === 0) {
      setTimerActive(false);
    }
    return () => clearInterval(interval);
  }, [timerActive, timerSeconds]);

  const startTimer = () => {
    if (selectedScenario?.timerDuration) {
      setTimerSeconds(selectedScenario.timerDuration);
      setTimerActive(true);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const callEmergency = () => {
    window.location.href = 'tel:108';
  };

  if (selectedScenario) {
    return (
      <div className="space-y-6">
        {/* Emergency Header */}
        <Card className="border-red-500 bg-red-50 dark:bg-red-900/20">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="text-red-500">{selectedScenario.icon}</div>
                <div>
                  <h2 className="text-2xl font-bold text-red-700 dark:text-red-400">
                    {selectedScenario.title}
                  </h2>
                  <p className="text-red-600 dark:text-red-300">
                    {selectedScenario.description}
                  </p>
                </div>
              </div>
              <Button
                onClick={() => setSelectedScenario(null)}
                variant="outline"
                className="border-red-300"
              >
                <ChevronLeft className="w-4 h-4 mr-2" />
                Back
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Emergency Call Button */}
        <div className="text-center">
          <Button onClick={callEmergency} variant="destructive" size="lg" className="text-xl px-8 py-4">
            <Phone className="w-6 h-6 mr-3" />
            Call 108 - EMERGENCY
          </Button>
        </div>

        {/* Timer */}
        {selectedScenario.timerDuration && (
          <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}>
            <CardContent className="pt-6">
              <div className="text-center space-y-4">
                <div className="flex items-center justify-center space-x-2">
                  <Timer className="w-6 h-6" />
                  <span className="text-lg font-semibold">Timer</span>
                </div>
                <div className="text-4xl font-bold font-mono">
                  {formatTime(timerSeconds)}
                </div>
                <Button
                  onClick={startTimer}
                  disabled={timerActive}
                  variant="outline"
                >
                  {timerActive ? 'Timer Running' : 'Start Timer'}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Steps */}
        <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}>
          <CardHeader>
            <CardTitle>Emergency Steps</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {selectedScenario.steps.map((step, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border-2 transition-all ${
                  currentStep === index
                    ? 'border-red-500 bg-red-50 dark:bg-red-900/20'
                    : darkMode ? 'border-gray-600' : 'border-gray-200'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold ${
                    currentStep === index
                      ? 'bg-red-500 text-white'
                      : darkMode ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-600'
                  }`}>
                    {index + 1}
                  </div>
                  <p className="flex-1 text-lg leading-relaxed">{step}</p>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button
            onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
            disabled={currentStep === 0}
            variant="outline"
          >
            Previous Step
          </Button>
          <Button
            onClick={() => setCurrentStep(Math.min(selectedScenario.steps.length - 1, currentStep + 1))}
            disabled={currentStep === selectedScenario.steps.length - 1}
          >
            Next Step
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Emergency Call Banner */}
      <Card className="border-red-500 bg-red-50 dark:bg-red-900/20">
        <CardContent className="pt-6">
          <div className="text-center space-y-4">
            <AlertTriangle className="w-16 h-16 mx-auto text-red-500" />
            <div>
              <h3 className="text-xl font-bold text-red-700 dark:text-red-400 mb-2">
                Emergency Situation?
              </h3>
              <p className="text-red-600 dark:text-red-300 mb-4">
                Call 108 immediately for any medical emergency
              </p>
            </div>
            <Button onClick={callEmergency} variant="destructive" size="lg">
              <Phone className="w-5 h-5 mr-2" />
              Call 108 Now
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Emergency Scenarios */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {emergencyScenarios.map((scenario) => (
          <Card
            key={scenario.id}
            className={`cursor-pointer transition-all hover:shadow-lg hover:scale-105 ${
              darkMode ? 'bg-gray-800 border-gray-700 hover:border-red-500' : 'bg-white border-gray-200 hover:border-red-500'
            }`}
            onClick={() => setSelectedScenario(scenario)}
          >
            <CardHeader className="text-center">
              <div className="flex justify-center text-red-500 mb-2">
                {scenario.icon}
              </div>
              <CardTitle className="text-lg">{scenario.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <p className={`text-sm text-center ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {scenario.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Important Notice */}
      <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'}>
        <CardContent className="pt-6">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-yellow-500 mt-0.5" />
            <div className="text-sm">
              <p className="font-semibold mb-1">Important Notice</p>
              <p className={darkMode ? 'text-gray-400' : 'text-gray-600'}>
                This guide provides first-aid instructions only and is not a substitute for professional medical care. 
                Always call 108 for medical emergencies. These instructions are based on standard emergency protocols 
                and should be used as guidance until professional help arrives.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}