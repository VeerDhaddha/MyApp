import React, { useState, useEffect } from 'react';
import { Upload, File, Lock, Unlock, Trash2, Eye, EyeOff } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { encryptData, decryptData } from '../utils/crypto';

interface StoredDocument {
  id: string;
  name: string;
  type: string;
  encryptedData: string;
  timestamp: number;
}

export default function DocumentUploader({ darkMode }: { darkMode: boolean }) {
  const [passphrase, setPassphrase] = useState('');
  const [documents, setDocuments] = useState<StoredDocument[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [showDecrypted, setShowDecrypted] = useState<{ [key: string]: boolean }>({});
  const [decryptedContent, setDecryptedContent] = useState<{ [key: string]: string }>({});
  const [error, setError] = useState('');

  useEffect(() => {
    const stored = localStorage.getItem('medsafe_documents');
    if (stored) {
      setDocuments(JSON.parse(stored));
    }
  }, []);

  const handleFileUpload = async (file: File) => {
    if (!passphrase) {
      setError('Please set a passphrase first');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const content = e.target?.result as string;
        const encrypted = await encryptData(content, passphrase);
        
        const newDoc: StoredDocument = {
          id: Date.now().toString(),
          name: file.name,
          type: file.type,
          encryptedData: encrypted,
          timestamp: Date.now(),
        };

        const updatedDocs = [...documents, newDoc];
        setDocuments(updatedDocs);
        localStorage.setItem('medsafe_documents', JSON.stringify(updatedDocs));
        setError('');
      } catch (err) {
        setError('Failed to encrypt file');
      }
    };
    reader.readAsText(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFileUpload(file);
  };

  const handleDecrypt = async (doc: StoredDocument) => {
    try {
      const decrypted = await decryptData(doc.encryptedData, passphrase);
      setDecryptedContent({ ...decryptedContent, [doc.id]: decrypted });
      setShowDecrypted({ ...showDecrypted, [doc.id]: true });
      setError('');
    } catch (err) {
      setError('Failed to decrypt - wrong passphrase?');
    }
  };

  const deleteDocument = (id: string) => {
    const updatedDocs = documents.filter(doc => doc.id !== id);
    setDocuments(updatedDocs);
    localStorage.setItem('medsafe_documents', JSON.stringify(updatedDocs));
    const newDecrypted = { ...decryptedContent };
    const newShow = { ...showDecrypted };
    delete newDecrypted[id];
    delete newShow[id];
    setDecryptedContent(newDecrypted);
    setShowDecrypted(newShow);
  };

  const clearAll = () => {
    if (confirm('Are you sure? This will delete all stored documents.')) {
      setDocuments([]);
      setDecryptedContent({});
      setShowDecrypted({});
      localStorage.removeItem('medsafe_documents');
    }
  };

  return (
    <div className="space-y-6">
      {/* Passphrase Input */}
      <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Lock className="w-5 h-5" />
            <span>Encryption Passphrase</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="passphrase">Set your encryption key</Label>
            <Input
              id="passphrase"
              type="password"
              value={passphrase}
              onChange={(e) => setPassphrase(e.target.value)}
              placeholder="Enter a strong passphrase"
              className={darkMode ? 'bg-gray-700 border-gray-600' : ''}
            />
          </div>
          {error && <p className="text-red-500 text-sm">{error}</p>}
        </CardContent>
      </Card>

      {/* File Upload Area */}
      <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}>
        <CardContent className="pt-6">
          <div
            onDrop={handleDrop}
            onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
            onDragLeave={() => setIsDragging(false)}
            className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
              isDragging
                ? 'border-red-500 bg-red-50 dark:bg-red-900/20'
                : darkMode ? 'border-gray-600' : 'border-gray-300'
            }`}
          >
            <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
            <p className="mb-2">Drag and drop files here, or click to select</p>
            <input
              type="file"
              onChange={(e) => e.target.files?.[0] && handleFileUpload(e.target.files[0])}
              className="hidden"
              id="file-upload"
            />
            <Button asChild>
              <label htmlFor="file-upload" className="cursor-pointer">
                Select Files
              </label>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Documents List */}
      {documents.length > 0 && (
        <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <File className="w-5 h-5" />
              <span>Stored Documents ({documents.length})</span>
            </CardTitle>
            <Button variant="destructive" size="sm" onClick={clearAll}>
              <Trash2 className="w-4 h-4 mr-2" />
              Clear All
            </Button>
          </CardHeader>
          <CardContent className="space-y-4">
            {documents.map((doc) => (
              <div
                key={doc.id}
                className={`p-4 rounded-lg border ${darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'}`}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <File className="w-4 h-4" />
                    <span className="font-medium">{doc.name}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => handleDecrypt(doc)}
                    >
                      {showDecrypted[doc.id] ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => deleteDocument(doc.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                {showDecrypted[doc.id] && (
                  <div className={`mt-2 p-3 rounded text-sm ${darkMode ? 'bg-gray-800' : 'bg-white'}`}>
                    <pre className="whitespace-pre-wrap break-all">
                      {decryptedContent[doc.id]}
                    </pre>
                  </div>
                )}
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}