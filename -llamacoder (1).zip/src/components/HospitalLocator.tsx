import React, { useState, useEffect } from 'react';
import { MapPin, Phone, Navigation, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { calculateDistance } from '../utils/haversine';
import hospitalsData from '../utils/hospitals.json';

interface Hospital {
  name: string;
  city: string;
  address: string;
  phone: string;
  type: string;
  latitude: number;
  longitude: number;
}

export default function HospitalLocator({ darkMode }: { darkMode: boolean }) {
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [nearbyHospitals, setNearbyHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const getLocation = () => {
    setLoading(true);
    setError('');
    
    if (!navigator.geolocation) {
      setError('Geolocation is not supported by your browser');
      setLoading(false);
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const location = {
          lat: position.coords.latitude,
          lng: position.coords.longitude,
        };
        setUserLocation(location);
        findNearbyHospitals(location);
        setLoading(false);
      },
      (err) => {
        setError('Unable to get your location. Please enable location services.');
        setLoading(false);
      }
    );
  };

  const findNearbyHospitals = (location: { lat: number; lng: number }) => {
    const hospitalsWithDistance = (hospitalsData as Hospital[]).map(hospital => ({
      ...hospital,
      distance: calculateDistance(
        location.lat,
        location.lng,
        hospital.latitude,
        hospital.longitude
      ),
    }));

    const sorted = hospitalsWithDistance
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 5);

    setNearbyHospitals(sorted);
  };

  const callHospital = (phone: string) => {
    window.location.href = `tel:${phone}`;
  };

  const callEmergency = () => {
    window.location.href = 'tel:108';
  };

  return (
    <div className="space-y-6">
      {/* Location Button */}
      <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}>
        <CardContent className="pt-6">
          <div className="text-center space-y-4">
            <Navigation className="w-16 h-16 mx-auto text-red-500" />
            <div>
              <h3 className="text-lg font-semibold mb-2">Find Nearby Hospitals</h3>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-4`}>
                Enable location services to find the 5 nearest hospitals
              </p>
            </div>
            <div className="flex justify-center space-x-4">
              <Button onClick={getLocation} disabled={loading} size="lg">
                {loading ? 'Getting Location...' : 'Get My Location'}
              </Button>
              <Button onClick={callEmergency} variant="destructive" size="lg">
                Call 108 (Emergency)
              </Button>
            </div>
            {error && (
              <div className="flex items-center justify-center space-x-2 text-red-500">
                <AlertCircle className="w-4 h-4" />
                <span className="text-sm">{error}</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* User Location Info */}
      {userLocation && (
        <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}>
          <CardContent className="pt-6">
            <div className="flex items-center space-x-2">
              <MapPin className="w-5 h-5 text-green-500" />
              <span className="text-sm">
                Your Location: {userLocation.lat.toFixed(4)}, {userLocation.lng.toFixed(4)}
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Nearby Hospitals List */}
      {nearbyHospitals.length > 0 && (
        <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'}>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <MapPin className="w-5 h-5" />
              <span>Nearest 5 Hospitals</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {nearbyHospitals.map((hospital, index) => (
              <div
                key={index}
                className={`p-4 rounded-lg border ${darkMode ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'}`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold text-lg">{hospital.name}</h4>
                    <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'} mb-1`}>
                      {hospital.address}, {hospital.city}
                    </p>
                    <div className="flex items-center space-x-4 text-sm">
                      <span className="font-medium text-red-500">
                        {hospital.distance.toFixed(1)} km away
                      </span>
                      <span className={`px-2 py-1 rounded text-xs ${
                        hospital.type === 'ER' 
                          ? 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400'
                          : 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400'
                      }`}>
                        {hospital.type}
                      </span>
                    </div>
                  </div>
                  <Button
                    onClick={() => callHospital(hospital.phone)}
                    size="sm"
                    className="ml-4"
                  >
                    <Phone className="w-4 h-4 mr-2" />
                    Call
                  </Button>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}