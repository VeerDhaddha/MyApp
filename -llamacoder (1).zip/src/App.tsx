import React, { useState, useEffect } from 'react';
import { Shield, MapPin, Heart, FileText, Moon, Sun } from 'lucide-react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './components/ui/card';
import DocumentUploader from './components/DocumentUploader';
import HospitalLocator from './components/HospitalLocator';
import EmergencyGuide from './components/EmergencyGuide';

type TabType = 'documents' | 'hospitals' | 'emergency';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('documents');
  const [darkMode, setDarkMode] = useState(true);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  const tabs = [
    { id: 'documents', label: 'Medical Documents', icon: FileText },
    { id: 'hospitals', label: 'Nearby Hospitals', icon: MapPin },
    { id: 'emergency', label: 'Emergency Guide', icon: Heart },
  ] as const;

  return (
    <div className={`min-h-screen ${darkMode ? 'bg-gray-900 text-white' : 'bg-white text-gray-900'} transition-colors duration-200`}>
      {/* Header */}
      <header className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'} border-b sticky top-0 z-40`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-3">
              <Shield className="w-8 h-8 text-red-500" />
              <h1 className="text-xl font-bold">MedSafe India</h1>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDarkMode(!darkMode)}
              className="p-2"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </header>

      {/* Tab Navigation */}
      <div className={`${darkMode ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'} border-b sticky top-16 z-30`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex space-x-8">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as TabType)}
                  className={`flex items-center space-x-2 py-4 px-1 border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'border-red-500 text-red-500'
                      : `border-transparent ${darkMode ? 'text-gray-400 hover:text-gray-200' : 'text-gray-500 hover:text-gray-700'}`
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="font-medium">{tab.label}</span>
                </button>
              );
            })}
          </nav>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Card className={darkMode ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'}>
            <CardHeader>
              <CardTitle className="text-lg">
                {activeTab === 'documents' && 'Secure Medical Document Storage'}
                {activeTab === 'hospitals' && 'Find Nearby Hospitals in India'}
                {activeTab === 'emergency' && 'Emergency First Response Guide'}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className={`text-sm ${darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                {activeTab === 'documents' && 'Upload and encrypt your medical documents. All data stays on your device.'}
                {activeTab === 'hospitals' && 'Locate the nearest hospitals using your device GPS. Works offline.'}
                {activeTab === 'emergency' && 'Step-by-step guidance for medical emergencies. Call 108 for immediate help.'}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Tab Content */}
        {activeTab === 'documents' && <DocumentUploader darkMode={darkMode} />}
        {activeTab === 'hospitals' && <HospitalLocator darkMode={darkMode} />}
        {activeTab === 'emergency' && <EmergencyGuide darkMode={darkMode} />}
      </main>
    </div>
  );
}